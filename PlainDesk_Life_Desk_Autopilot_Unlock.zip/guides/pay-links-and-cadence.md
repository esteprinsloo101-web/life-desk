# Pay links & cadence (quick)

1. Keep each bill/process linked to the **exact** portal you already use (bank, municipal, insurer).
2. When a reminder fires, open the link yourself → pay → mark **Done** in the wizard.
3. Cadence + lead days set the next Today item — no spreadsheet rebuild.
4. Export JSON after a clean week so you can restore on a new phone.
5. Kids / insurance / retire modules: toggle in Settings; unused modules stay hidden.
